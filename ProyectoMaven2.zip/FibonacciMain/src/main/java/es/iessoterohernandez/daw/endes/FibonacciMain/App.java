package es.iessoterohernandez.daw.endes.FibonacciMain;

import es.iessoterohernandez.daw.endes.Fibonacci1.Fibonacci;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        Fibonacci f = new Fibonacci();
        f.FibonacciCalculo();
        
    }
}
