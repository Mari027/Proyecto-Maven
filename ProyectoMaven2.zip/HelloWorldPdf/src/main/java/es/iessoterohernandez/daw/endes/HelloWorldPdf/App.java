package es.iessoterohernandez.daw.endes.HelloWorldPdf;

/**
 * Hello world!
 *
 */
import com.itextpdf.kernel.pdf.PdfWriter; 
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Paragraph;

public class App 
{
    public static void main( String[] args )
    {
    	String dest = "HelloWorldPdf.pdf";
        
        try {
            // Initialize PDF writer
            PdfWriter writer = new PdfWriter(dest);
            
            // Initialize PDF document
            PdfDocument pdf = new PdfDocument(writer);
            
            // Initialize document
            Document document = new Document(pdf);
            
            // Add a paragraph to the document
            document.add(new Paragraph("¡Hola, mundo!"));
            
            // Close document
            document.close();
            
            System.out.println("El pdf creado se llama: " + dest);
        } catch (Exception e) {
            e.printStackTrace();}
    }
}
