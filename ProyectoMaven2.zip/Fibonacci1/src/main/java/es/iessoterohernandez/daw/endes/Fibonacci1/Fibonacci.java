/**
 * 
 */
package es.iessoterohernandez.daw.endes.Fibonacci1;

/**
 * 
 */
public class Fibonacci {
	int a = 0;
	int b = 1;
	int resultado;
	public void FibonacciCalculo() {
		for (int i = 0; i < 10; i++) {
			resultado = a + b;
			a = b;
			b = resultado;
			System.out.println(resultado);
			
	}
	
	}
}
